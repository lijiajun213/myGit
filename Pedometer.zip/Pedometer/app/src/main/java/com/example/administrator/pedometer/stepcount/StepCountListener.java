package com.example.administrator.pedometer.stepcount;

public interface StepCountListener {
    public void countStep();
}
