package com.example.administrator.pedometer.activityAndServices;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import com.example.administrator.pedometer.R;
import com.example.administrator.pedometer.adapter.CommonAdapter;
import com.example.administrator.pedometer.adapter.CommonViewHolder;
import com.example.administrator.pedometer.bean.StepEntity;
import com.example.administrator.pedometer.db.StepDataDao;

import java.util.List;

public class HistoryActivity extends AppCompatActivity {
    private LinearLayout layout_titlebar;
    private ImageView iv_left;
    private ListView lv;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        layout_titlebar = (LinearLayout) findViewById(R.id.layout_titlebar);
        iv_left = (ImageView) findViewById(R.id.iv_left);
        lv = (ListView) findViewById(R.id.lv);
        iv_left.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        initData();
    }
    private void initData() {
        StepDataDao stepDataDao = new StepDataDao(this);
        List<StepEntity> StepEntity =stepDataDao.getAllDatas();
        lv.setAdapter(new CommonAdapter<StepEntity>(this,StepEntity,R.layout.item) {
            @Override
            protected void convertView(View item, StepEntity stepEntity) {
                TextView tv_date= CommonViewHolder.get(item,R.id.tv_date);
                TextView tv_step= CommonViewHolder.get(item,R.id.tv_step);
                tv_date.setText(stepEntity.getCurDate());
                tv_step.setText(stepEntity.getSteps()+"步");
            }
        });

    }

}
