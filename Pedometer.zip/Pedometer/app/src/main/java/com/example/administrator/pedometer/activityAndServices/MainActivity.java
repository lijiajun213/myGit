package com.example.administrator.pedometer.activityAndServices;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.app.Activity;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import com.example.administrator.pedometer.R;
import com.example.administrator.pedometer.UpdateUiCallBack;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private TextView tv_set;
    private TextView tv_data;
    private TextView tv_step;
    private TextView tv_plan;
    private StepService mService;
    private boolean mIsRunning;
    private SharedPreferences sp1;
    private SharedPreferences sp3;
    private Handler mHandler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == 1){
                tv_step.setText(sp1.getString("steps","0"));
                tv_plan.setText(sp3.getString("plan", "0"));
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv_step = (TextView) findViewById(R.id.step_tv);
        tv_data = (TextView) findViewById(R.id.tv_data);
        tv_set = (TextView) findViewById(R.id.tv_set);
        tv_plan = (TextView) findViewById(R.id.tv_plan);
        sp1 = getSharedPreferences("steps",Activity.MODE_PRIVATE);
        sp3 = getSharedPreferences("plan",Activity.MODE_PRIVATE);

        addListener();
        startStepService();
    }

    private void addListener() {
        tv_set.setOnClickListener(this);
        tv_data.setOnClickListener(this);
    }

    protected void onDestroy() {
        super.onDestroy();
//        stopStepService();
    }

    protected void onPause() {
        unbindStepService();
        super.onPause();
    }

    protected void onResume() {
        super.onResume();
        tv_step.setText(sp1.getString("steps", "0"));
        tv_plan.setText(sp3.getString("plan", "0"));
        if (this.mIsRunning){
            bindStepService();
        }
    }



    private UpdateUiCallBack mUiCallback = new UpdateUiCallBack() {
        @Override
        public void updateUi() {
            Message message = mHandler.obtainMessage();
            message.what = 1;
            mHandler.sendMessage(message);
        }
    };

    private ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            StepService.StepBinder binder = (StepService.StepBinder) service;
            mService = binder.getService();
            mService.registerCallback(mUiCallback);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {

        }
    };

    private void bindStepService() {
        bindService(new Intent(this, StepService.class), this.mConnection, Context.BIND_AUTO_CREATE);
    }

    private void unbindStepService() {
        unbindService(this.mConnection);
    }

    private void startStepService() {
        this.mIsRunning = true;
        startService(new Intent(this, StepService.class));
    }

    private void stopStepService() {
        this.mIsRunning = false;
        if (this.mService != null)
            stopService(new Intent(this, StepService.class));
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_set:
                startActivity(new Intent(this, SetPlanActivity.class));
                break;
            case R.id.tv_data:
                startActivity(new Intent(this, HistoryActivity.class));
                break;
        }
    }

}
