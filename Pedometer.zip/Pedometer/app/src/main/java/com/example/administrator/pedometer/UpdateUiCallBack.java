package com.example.administrator.pedometer;

public interface UpdateUiCallBack {
    public void updateUi();
}
