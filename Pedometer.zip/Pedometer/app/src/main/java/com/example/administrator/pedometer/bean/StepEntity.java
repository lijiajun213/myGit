package com.example.administrator.pedometer.bean;

/**
 * Created by Administrator on 2017/6/12.
 */

public class StepEntity {
    private int id;
    private String curDate; //当天的日期
    private String steps;   //当天的步数

    public StepEntity() {
    }

    public StepEntity(String curDate, String steps) {
        this.curDate = curDate;
        this.steps = steps;
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCurDate() {
        return curDate;
    }

    public void setCurDate(String curDate) {
        this.curDate = curDate;
    }

    public String getSteps() {
        return steps;
    }

    public void setSteps(String steps) {
        this.steps = steps;
    }


    @Override
    public String toString() {
        return "StepData{" +
                "id=" + id +
                ", curDate='" + curDate + '\'' +
                ", steps='" + steps + '\'' +
                '}';
    }
}