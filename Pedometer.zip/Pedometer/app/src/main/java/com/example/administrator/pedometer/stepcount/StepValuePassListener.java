package com.example.administrator.pedometer.stepcount;

public interface StepValuePassListener {
    public void stepChanged(int steps);
}
