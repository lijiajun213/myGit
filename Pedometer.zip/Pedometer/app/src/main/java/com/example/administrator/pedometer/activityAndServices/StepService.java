package com.example.administrator.pedometer.activityAndServices;

import android.app.Activity;
import android.app.Notification;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Binder;
import android.os.IBinder;
import com.example.administrator.pedometer.bean.StepEntity;
import com.example.administrator.pedometer.db.StepDataDao;
import com.example.administrator.pedometer.stepcount.StepCount;
import com.example.administrator.pedometer.stepcount.StepDetector;
import com.example.administrator.pedometer.stepcount.StepValuePassListener;
import com.example.administrator.pedometer.UpdateUiCallBack;

import java.text.SimpleDateFormat;
import java.util.Date;



public class StepService extends Service {
    private BroadcastReceiver mBatInfoReceiver;
    private static String CURRENT_DATE = "";
    private final IBinder mBinder = new StepBinder();
    private UpdateUiCallBack mCallback;
    private Sensor mSensor;
    private SensorManager mSensorManager;
    private StepCount mStepCount;
    private StepDetector mStepDetector;
    private SharedPreferences sp1;
    private SharedPreferences sp2;
    private SharedPreferences sp3;
    private SharedPreferences.Editor mEdit1;
    private SharedPreferences.Editor mEdit2;
    private SharedPreferences.Editor mEdit3;

    private StepDataDao stepDataDao;
    private int CURRENT_STEP;

    private StepValuePassListener mValuePassListener = new StepValuePassListener() {
        @Override
        public void stepChanged(int steps) {
            CURRENT_STEP = steps;
            mEdit1.putString("steps", steps +  "");
            mEdit1.commit();
//            saveStepData();
            mCallback.updateUi();
            String plan = sp2.getString("planWalk_QTY","");
            if(Integer.parseInt(plan) - steps > 0){
                String temp =  Integer.toString(Integer.parseInt(plan) - steps) ;
                mEdit3.putString("plan","距离目标达成还差"+ temp + "步");
                mEdit3.commit();
            }
            else{
                mEdit3.putString("plan","今天的目标已达成");
                mEdit3.commit();
            }

        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return this.mBinder;
    }


    public void onCreate() {
        super.onCreate();
        this.mStepDetector = new StepDetector();
        this.mSensorManager = ((SensorManager)getSystemService(Context.SENSOR_SERVICE));
        this.mSensor = this.mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        this.mSensorManager.registerListener(this.mStepDetector, this.mSensor, SensorManager.SENSOR_DELAY_UI);
        this.mStepCount = new StepCount();
        this.mStepCount.initListener(this.mValuePassListener);
        this.mStepDetector.initListener(this.mStepCount);
        this.sp1 = getSharedPreferences("steps", Activity.MODE_PRIVATE);
        this.mEdit1 = this.sp1.edit();
        this.sp2 = getSharedPreferences("planWalk_QTY", Activity.MODE_PRIVATE);
        this.mEdit2 = this.sp2.edit();
        this.sp3 = getSharedPreferences("plan", Activity.MODE_PRIVATE);
        this.mEdit3 = this.sp3.edit();
        initTodayData();
        initBroadcastReceiver();

    }


    private void initBroadcastReceiver() {
        final IntentFilter filter = new IntentFilter();
        // 屏幕灭屏广播
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        //关机广播
        filter.addAction(Intent.ACTION_SHUTDOWN);
        // 屏幕解锁广播
        filter.addAction(Intent.ACTION_USER_PRESENT);
        // 当长按电源键弹出“关机”对话或者锁屏时系统会发出这个广播
        filter.addAction(Intent.ACTION_CLOSE_SYSTEM_DIALOGS);
        //监听日期变化
        filter.addAction(Intent.ACTION_DATE_CHANGED);
        filter.addAction(Intent.ACTION_TIME_CHANGED);
        filter.addAction(Intent.ACTION_TIME_TICK);

        mBatInfoReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                switch (action) {
                    // 屏幕灭屏广播
                    case Intent.ACTION_SCREEN_OFF:
                        saveStepData();
                        break;
                    //关机广播，保存好当前数据
                    case Intent.ACTION_SHUTDOWN:
                        saveStepData();
                        break;
                    // 屏幕解锁广播
                    case Intent.ACTION_USER_PRESENT:
                        break;
                    // 当长按电源键弹出“关机”对话或者锁屏时系统会发出这个广播
                    case Intent.ACTION_CLOSE_SYSTEM_DIALOGS:
                        saveStepData();
                        break;
                    //监听日期变化
                    case Intent.ACTION_DATE_CHANGED:
                    case Intent.ACTION_TIME_CHANGED:
                    case Intent.ACTION_TIME_TICK:
                        saveStepData();
                        isNewDay();
                        break;
                    default:
                        break;
                }
            }
        };
        //注册广播
        registerReceiver(mBatInfoReceiver, filter);
    }
    private String getTodayDate() {
        Date date = new Date(System.currentTimeMillis());
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return sdf.format(date);
    }

    private void initTodayData() {
        //获取当前时间
        CURRENT_DATE = getTodayDate();
        //获取数据库
        stepDataDao = new StepDataDao(getApplicationContext());
        //获取当天的数据，用于展示
        StepEntity entity = stepDataDao.getCurDataByDate(CURRENT_DATE);
        //为空则说明还没有该天的数据，有则说明已经开始当天的计步了
        if (entity == null) {
            CURRENT_STEP = 0;
        } else {
            CURRENT_STEP = Integer.parseInt(entity.getSteps());
        }
    }

    private void saveStepData(){
        CURRENT_DATE = getTodayDate();
        StepEntity entity = stepDataDao.getCurDataByDate(CURRENT_DATE);
        //为空则说明还没有该天的数据，有则说明已经开始当天的计步了
        if (entity == null) {
            //没有则新建一条数据
            entity = new StepEntity();
            entity.setCurDate(CURRENT_DATE);
            entity.setSteps(String.valueOf(CURRENT_STEP));

            stepDataDao.addNewData(entity);
        } else {
            //有则更新当前的数据
            entity.setSteps(String.valueOf(CURRENT_STEP));

            stepDataDao.updateCurData(entity);
        }

    }

    private void isNewDay() {
        String time = "00:00";
        CURRENT_DATE = getTodayDate();
        if (time.equals(new SimpleDateFormat("HH:mm").format(new Date())) || !CURRENT_DATE.equals(getTodayDate())) {
            resetValues();
        }
    }

    public void onDestroy() {
        super.onDestroy();
        stopForeground(true);
        unregisterReceiver(mBatInfoReceiver);
    }

    public void registerCallback(UpdateUiCallBack paramICallback) {
        this.mCallback = paramICallback;
    }

    //重置StepCount
    public void resetValues() {
        mEdit1.putString("steps","0");
        mEdit1.commit();
        this.mStepCount.setSteps(0);
    }

    public boolean onUnbind(Intent paramIntent) {
        return super.onUnbind(paramIntent);
    }

    public class StepBinder extends Binder {
        StepService getService() {
            return StepService.this;
        }
    }



}
