package com.example.administrator.pedometer.activityAndServices;

import android.app.Activity;
import android.app.TimePickerDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.content.SharedPreferences;

import com.example.administrator.pedometer.R;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;



public class SetPlanActivity extends AppCompatActivity implements View.OnClickListener {
    private SharedPreferences sp;
    private LinearLayout layout_titlebar;
    private ImageView iv_left;
    private ImageView iv_right;
    private EditText tv_step_number;

    private Button btn_save;
    private String walk_qty;

    private void assignViews() {
        layout_titlebar = (LinearLayout) findViewById(R.id.layout_titlebar);
        iv_left = (ImageView) findViewById(R.id.iv_left);
        iv_right = (ImageView) findViewById(R.id.iv_right);
        tv_step_number = (EditText) findViewById(R.id.tv_step_number);
        btn_save = (Button) findViewById(R.id.btn_save);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_plan);
        assignViews();
        initData();
        addListener();
    }

    public void initData() {//获取锻炼计划
        sp = getSharedPreferences("planWalk_QTY", Activity.MODE_PRIVATE);
        String planWalk_QTY = sp.getString("planWalk_QTY", "2000");
        if (!planWalk_QTY.isEmpty()) {
            if ("0".equals(planWalk_QTY)) {
                tv_step_number.setText("2000");
            } else {
                tv_step_number.setText(planWalk_QTY);
            }
        }

    }


    public void addListener() {
        iv_left.setOnClickListener(this);
        iv_right.setOnClickListener(this);
        btn_save.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_left:
                finish();
                break;
            case R.id.btn_save:
                save();
                break;
        }
    }

    private void save() {
        walk_qty = tv_step_number.getText().toString().trim();
        SharedPreferences.Editor mEditor = sp.edit();
        if (walk_qty.isEmpty() || "0".equals(walk_qty)) {
            mEditor.putString("planWalk_QTY", "2000");
            mEditor.commit();
        } else {
            mEditor.putString("planWalk_QTY", walk_qty);
            mEditor.commit();
        }

        finish();
    }

}